#include"information.h"

int main()
{
	
	announce();
	f_menu();
	return 0;
}